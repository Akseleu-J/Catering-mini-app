/**
 * frontend/js/app.js
 * Main Mini App controller.
 * Handles: catalog, product detail, cart, checkout, order history.
 * Single-page app with hash-based navigation.
 */

import Telegram from "./telegram.js";
import API      from "./api.js";

// ── App State ─────────────────────────────────────────────────────────────────

const state = {
  user:         null,
  categories:   [],
  products:     [],
  currentCat:   null,
  currentPage:  0,
  totalPages:   1,
  cart:         { items: [], total: 0, count: 0 },
  selectedProduct: null,
  checkoutData: {},
  orders:       [],
  view:         "home",          // home | catalog | product | cart | checkout | orders
};

// ── DOM helpers ───────────────────────────────────────────────────────────────

const $  = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function show(id) {
  $$(".view").forEach(el => el.classList.remove("active"));
  const el = document.getElementById(id);
  if (el) el.classList.add("active");
}

function setHtml(id, html) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html;
}

function toast(msg, type = "info") {
  const el = document.createElement("div");
  el.className = `toast toast--${type}`;
  el.textContent = msg;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add("toast--show"));
  setTimeout(() => { el.classList.remove("toast--show"); setTimeout(() => el.remove(), 300); }, 3000);
}

function fmtPrice(n) {
  return Number(n).toLocaleString("ru-RU") + " ₸";
}

function loader(show) {
  const el = $("#loader");
  if (el) el.style.display = show ? "flex" : "none";
}

// ── Navigation ────────────────────────────────────────────────────────────────

function navigate(view, params = {}) {
  state.view = view;
  Telegram.hideMainButton();

  switch (view) {
    case "home":
      Telegram.hideBack();
      show("view-home");
      renderHome();
      break;

    case "catalog":
      Telegram.showBack(() => navigate("home"));
      show("view-catalog");
      loadCatalog(params.catId, params.page || 0);
      break;

    case "product":
      Telegram.showBack(() => navigate("catalog", { catId: state.currentCat?.id }));
      show("view-product");
      renderProduct(params.product);
      break;

    case "cart":
      Telegram.showBack(() => navigate("home"));
      show("view-cart");
      loadCart();
      break;

    case "checkout":
      Telegram.showBack(() => navigate("cart"));
      show("view-checkout");
      renderCheckout();
      break;

    case "orders":
      Telegram.showBack(() => navigate("home"));
      show("view-orders");
      loadOrders();
      break;

    case "order-success":
      Telegram.hideBack();
      show("view-order-success");
      renderOrderSuccess(params.order);
      break;
  }
}

// ── HOME ──────────────────────────────────────────────────────────────────────

async function renderHome() {
  if (!state.user) return;

  const name = state.user.first_name || "друг";
  setHtml("home-greeting", `Привет, <strong>${name}</strong>! 👋`);

  // Update cart badge
  updateCartBadge();
}

function updateCartBadge() {
  const badge = $("#cart-badge");
  if (badge) {
    const count = state.cart.count;
    badge.textContent = count;
    badge.style.display = count > 0 ? "flex" : "none";
  }
}

// ── CATALOG ───────────────────────────────────────────────────────────────────

async function loadCategories() {
  try {
    state.categories = await API.getCategories();
    renderCategoryTabs();
  } catch (e) {
    toast("Ошибка загрузки категорий", "error");
  }
}

function renderCategoryTabs() {
  const html = state.categories.map(cat => `
    <button class="cat-tab" data-cat-id="${cat.id}">
      <span class="cat-tab__emoji">${cat.emoji}</span>
      <span class="cat-tab__name">${cat.name}</span>
    </button>
  `).join("");

  setHtml("category-tabs", html);

  $$(".cat-tab").forEach(btn => {
    btn.addEventListener("click", () => {
      $$(".cat-tab").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const catId = parseInt(btn.dataset.catId);
      state.currentCat = state.categories.find(c => c.id === catId);
      loadCatalog(catId, 0);
    });
  });

  // Auto-select first
  if (state.categories.length > 0) {
    const first = $("#category-tabs .cat-tab");
    if (first) first.click();
  }
}

async function loadCatalog(catId, page = 0) {
  loader(true);
  try {
    const data = await API.getProducts(catId, page);
    state.products   = data.products;
    state.currentPage = data.page;
    state.totalPages  = data.pages;
    renderProducts();
    renderPagination(catId);
  } catch (e) {
    toast("Ошибка загрузки меню", "error");
  } finally {
    loader(false);
  }
}

function renderProducts() {
  if (!state.products.length) {
    setHtml("products-grid", `<div class="empty-state">😔 В этой категории пока нет блюд</div>`);
    return;
  }

  const html = state.products.map(p => `
    <div class="product-card" data-id="${p.id}">
      <div class="product-card__img-wrap">
        ${p.photo_file_id
          ? `<img class="product-card__img" src="/api/v1/photo/${p.photo_file_id}" alt="${p.name}" loading="lazy" onerror="this.style.display='none'">`
          : `<div class="product-card__no-img">🍽</div>`
        }
        ${!p.is_available ? `<div class="product-card__stoplist">Стоп-лист</div>` : ""}
      </div>
      <div class="product-card__body">
        <h3 class="product-card__name">${p.name}</h3>
        <p class="product-card__desc">${p.description || ""}</p>
        <div class="product-card__footer">
          <span class="product-card__price">${fmtPrice(p.price)}</span>
          <span class="product-card__serving">👥 на ${p.serving_factor} чел.</span>
        </div>
        ${p.is_available
          ? `<button class="btn btn--primary product-card__btn" data-id="${p.id}">В корзину</button>`
          : `<button class="btn btn--disabled" disabled>Недоступно</button>`
        }
      </div>
    </div>
  `).join("");

  setHtml("products-grid", html);

  // Click on card — open detail
  $$(".product-card").forEach(card => {
    card.addEventListener("click", (e) => {
      if (e.target.closest(".product-card__btn")) return;
      const id = parseInt(card.dataset.id);
      const product = state.products.find(p => p.id === id);
      if (product) navigate("product", { product });
    });
  });

  // Click on "В корзину" — show mode selector
  $$(".product-card__btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const id = parseInt(btn.dataset.id);
      const product = state.products.find(p => p.id === id);
      if (product) showAddModal(product);
    });
  });
}

function renderPagination(catId) {
  const html = state.totalPages <= 1 ? "" : `
    <div class="pagination">
      <button class="btn btn--ghost" ${state.currentPage === 0 ? "disabled" : ""}
        onclick="app.prevPage(${catId})">⬅️</button>
      <span>${state.currentPage + 1} / ${state.totalPages}</span>
      <button class="btn btn--ghost" ${state.currentPage >= state.totalPages - 1 ? "disabled" : ""}
        onclick="app.nextPage(${catId})">➡️</button>
    </div>
  `;
  setHtml("pagination", html);
}

// ── PRODUCT DETAIL ────────────────────────────────────────────────────────────

function renderProduct(product) {
  state.selectedProduct = product;
  const html = `
    <div class="product-detail">
      ${product.photo_file_id
        ? `<img class="product-detail__img" src="/api/v1/photo/${product.photo_file_id}" alt="${product.name}">`
        : `<div class="product-detail__no-img">🍽</div>`
      }
      <div class="product-detail__body">
        <h2 class="product-detail__name">${product.name}</h2>
        <p class="product-detail__desc">${product.description || "Описание отсутствует"}</p>
        <div class="product-detail__meta">
          <div class="meta-row">
            <span>💰 Цена</span>
            <strong>${fmtPrice(product.price)}</strong>
          </div>
          <div class="meta-row">
            <span>👥 1 порция на</span>
            <strong>${product.serving_factor} человек</strong>
          </div>
        </div>
        <div class="product-detail__actions">
          <button class="btn btn--primary btn--lg" id="btn-add-manual">
            🧮 Добавить (штуки)
          </button>
          <button class="btn btn--outline btn--lg" id="btn-add-guests">
            👥 Добавить (по гостям)
          </button>
        </div>
      </div>
    </div>
  `;
  setHtml("view-product", html);

  document.getElementById("btn-add-manual")?.addEventListener("click", () => showAddModal(product, "manual"));
  document.getElementById("btn-add-guests")?.addEventListener("click", () => showAddModal(product, "per_person"));
}

// ── ADD TO CART MODAL ─────────────────────────────────────────────────────────

function showAddModal(product, presetMode = null) {
  Telegram.haptic.light();

  const modal = document.createElement("div");
  modal.className = "modal-overlay";
  modal.innerHTML = `
    <div class="modal">
      <div class="modal__header">
        <h3>${product.name}</h3>
        <button class="modal__close" id="modal-close">✕</button>
      </div>

      <div class="modal__tabs" id="mode-tabs">
        <button class="tab-btn ${presetMode !== "per_person" ? "active" : ""}" data-mode="manual">
          🧮 Штуки
        </button>
        <button class="tab-btn ${presetMode === "per_person" ? "active" : ""}" data-mode="per_person">
          👥 По гостям
        </button>
      </div>

      <div class="modal__body">
        <!-- Manual mode -->
        <div class="mode-panel ${presetMode === "per_person" ? "hidden" : ""}" id="panel-manual">
          <label class="input-label">Количество порций</label>
          <div class="qty-control">
            <button class="qty-btn" id="qty-minus">−</button>
            <input class="qty-input" id="qty-value" type="number" min="1" value="1">
            <button class="qty-btn" id="qty-plus">+</button>
          </div>
          <p class="hint">Итого: <strong id="manual-total">${fmtPrice(product.price)}</strong></p>
        </div>

        <!-- Per-person mode -->
        <div class="mode-panel ${presetMode !== "per_person" ? "hidden" : ""}" id="panel-guests">
          <label class="input-label">Количество гостей</label>
          <input class="text-input" id="guests-value" type="number" min="1" placeholder="Например: 50">
          <p class="hint" id="guests-hint">
            1 порция на ${product.serving_factor} чел.
          </p>
          <p class="hint" id="guests-calc"></p>
        </div>
      </div>

      <button class="btn btn--primary btn--full" id="btn-add-confirm">
        ✅ Добавить в корзину
      </button>
    </div>
  `;

  document.body.appendChild(modal);

  let currentMode = presetMode || "manual";

  // Tab switching
  modal.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      currentMode = btn.dataset.mode;
      modal.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById("panel-manual").classList.toggle("hidden", currentMode !== "manual");
      document.getElementById("panel-guests").classList.toggle("hidden", currentMode !== "per_person");
    });
  });

  // Quantity controls
  const qtyInput = modal.querySelector("#qty-value");
  const manualTotal = modal.querySelector("#manual-total");

  modal.querySelector("#qty-minus").addEventListener("click", () => {
    const v = Math.max(1, parseInt(qtyInput.value) - 1);
    qtyInput.value = v;
    manualTotal.textContent = fmtPrice(product.price * v);
  });
  modal.querySelector("#qty-plus").addEventListener("click", () => {
    const v = parseInt(qtyInput.value) + 1;
    qtyInput.value = v;
    manualTotal.textContent = fmtPrice(product.price * v);
  });
  qtyInput.addEventListener("input", () => {
    const v = Math.max(1, parseInt(qtyInput.value) || 1);
    manualTotal.textContent = fmtPrice(product.price * v);
  });

  // Guest count calc preview
  const guestsInput = modal.querySelector("#guests-value");
  const guestsCalc  = modal.querySelector("#guests-calc");
  guestsInput.addEventListener("input", () => {
    const g = parseInt(guestsInput.value) || 0;
    if (g > 0) {
      const qty   = Math.ceil(g / product.serving_factor);
      const total = qty * product.price;
      guestsCalc.innerHTML = `→ <strong>${qty} порций</strong> · ${fmtPrice(total)}`;
    } else {
      guestsCalc.textContent = "";
    }
  });

  // Confirm button
  modal.querySelector("#btn-add-confirm").addEventListener("click", async () => {
    const btn = modal.querySelector("#btn-add-confirm");
    btn.disabled = true;
    btn.textContent = "Добавляю...";

    try {
      let body;
      if (currentMode === "per_person") {
        const guests = parseInt(guestsInput.value);
        if (!guests || guests <= 0) { toast("Введите количество гостей", "error"); btn.disabled = false; btn.textContent = "✅ Добавить в корзину"; return; }
        body = { product_id: product.id, guests_count: guests, calc_mode: "per_person" };
      } else {
        const qty = parseInt(qtyInput.value) || 1;
        body = { product_id: product.id, quantity: qty, calc_mode: "manual" };
      }

      await API.addToCart(body);
      Telegram.haptic.success();
      toast("✅ Добавлено в корзину!");
      await refreshCart();
      closeModal();
    } catch (e) {
      Telegram.haptic.error();
      toast(e.message || "Ошибка", "error");
      btn.disabled = false;
      btn.textContent = "✅ Добавить в корзину";
    }
  });

  // Close
  modal.querySelector("#modal-close").addEventListener("click", closeModal);
  modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); });

  function closeModal() { modal.remove(); }

  // Focus guest input if preset
  if (presetMode === "per_person") setTimeout(() => guestsInput.focus(), 100);
}

// ── CART ──────────────────────────────────────────────────────────────────────

async function loadCart() {
  loader(true);
  try {
    await refreshCart();
    renderCart();
  } catch (e) {
    toast("Ошибка загрузки корзины", "error");
  } finally {
    loader(false);
  }
}

async function refreshCart() {
  try {
    state.cart = await API.getCart();
    updateCartBadge();
  } catch (_) {}
}

function renderCart() {
  const { items, total, count } = state.cart;

  if (!count) {
    setHtml("view-cart", `
      <div class="view-header"><h2>🛒 Корзина</h2></div>
      <div class="empty-state">
        <span>🛒</span>
        <p>Корзина пуста</p>
        <button class="btn btn--primary" onclick="app.goTo('catalog')">Перейти в меню</button>
      </div>
    `);
    Telegram.hideMainButton();
    return;
  }

  const itemsHtml = items.map(item => `
    <div class="cart-item" data-id="${item.product_id}">
      <div class="cart-item__info">
        <span class="cart-item__name">${item.product_name}</span>
        <span class="cart-item__meta">
          ${item.calc_mode === "per_person"
            ? `👥 ${item.guests_count} гостей → ${item.quantity} порц.`
            : `🧮 ${item.quantity} шт.`
          }
        </span>
        <span class="cart-item__price">${fmtPrice(item.subtotal)}</span>
      </div>
      <button class="cart-item__remove" data-id="${item.product_id}">✕</button>
    </div>
  `).join("");

  setHtml("view-cart", `
    <div class="view-header">
      <h2>🛒 Корзина <span class="badge">${count}</span></h2>
      <button class="btn btn--ghost btn--sm" id="btn-clear-cart">Очистить</button>
    </div>
    <div class="cart-items">${itemsHtml}</div>
    <div class="cart-total">
      <span>Итого:</span>
      <strong>${fmtPrice(total)}</strong>
    </div>
  `);

  // Remove item buttons
  $$(".cart-item__remove").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = parseInt(btn.dataset.id);
      Telegram.haptic.light();
      try {
        await API.removeFromCart(id);
        await refreshCart();
        renderCart();
        toast("Удалено из корзины");
      } catch (e) {
        toast("Ошибка удаления", "error");
      }
    });
  });

  // Clear cart
  document.getElementById("btn-clear-cart")?.addEventListener("click", async () => {
    const ok = await Telegram.confirm("Очистить всю корзину?");
    if (!ok) return;
    await API.clearCart();
    await refreshCart();
    renderCart();
  });

  // Main button — checkout
  Telegram.showMainButton(`Оформить заказ · ${fmtPrice(total)}`, () => navigate("checkout"));
}

// ── CHECKOUT ──────────────────────────────────────────────────────────────────

function renderCheckout() {
  setHtml("view-checkout", `
    <div class="view-header"><h2>📋 Оформление заказа</h2></div>
    <form class="checkout-form" id="checkout-form">

      <div class="form-group">
        <label class="form-label">👤 Ваше имя</label>
        <input class="text-input" id="f-name" type="text"
          placeholder="Как к вам обращаться?"
          value="${state.user?.first_name || ""}">
      </div>

      <div class="form-group">
        <label class="form-label">📅 Дата мероприятия</label>
        <input class="text-input" id="f-date" type="date"
          min="${new Date(Date.now() + 86400000).toISOString().split("T")[0]}">
        <span class="form-hint">Минимум за 24 часа</span>
      </div>

      <div class="form-group">
        <label class="form-label">⏰ Время начала</label>
        <input class="text-input" id="f-time" type="time" value="14:00">
      </div>

      <div class="form-group">
        <label class="form-label">📍 Адрес / локация</label>
        <textarea class="text-input" id="f-location" rows="2"
          placeholder="Ул. Байтурсынова 5, зал «Алтын»"></textarea>
      </div>

      <div class="order-summary" id="order-summary">
        ${renderOrderSummaryHTML()}
      </div>

    </form>
  `);

  Telegram.showMainButton("✅ Подтвердить заказ", submitCheckout);
}

function renderOrderSummaryHTML() {
  const { items, total } = state.cart;
  const rows = items.map(i => `
    <div class="summary-row">
      <span>${i.product_name} × ${i.quantity}</span>
      <span>${fmtPrice(i.subtotal)}</span>
    </div>
  `).join("");
  return `
    <h4>Ваш заказ:</h4>
    ${rows}
    <div class="summary-row summary-row--total">
      <strong>Итого</strong>
      <strong>${fmtPrice(total)}</strong>
    </div>
  `;
}

async function submitCheckout() {
  const name     = document.getElementById("f-name")?.value.trim();
  const dateVal  = document.getElementById("f-date")?.value;
  const timeVal  = document.getElementById("f-time")?.value;
  const location = document.getElementById("f-location")?.value.trim();

  if (!name)     { Telegram.haptic.error(); toast("Введите имя", "error"); return; }
  if (!dateVal)  { Telegram.haptic.error(); toast("Выберите дату", "error"); return; }
  if (!timeVal)  { Telegram.haptic.error(); toast("Выберите время", "error"); return; }
  if (!location) { Telegram.haptic.error(); toast("Введите адрес", "error"); return; }

  // Convert native date input (YYYY-MM-DD) to DD.MM.YYYY
  const [y, m, d] = dateVal.split("-");
  const eventDate = `${d}.${m}.${y}`;

  Telegram.mainButtonLoading(true);

  try {
    const order = await API.checkout({
      client_name: name,
      event_date:  eventDate,
      event_time:  timeVal,
      location,
    });
    Telegram.haptic.success();
    await refreshCart();
    navigate("order-success", { order });
  } catch (e) {
    Telegram.haptic.error();
    toast(e.message || "Ошибка оформления", "error");
  } finally {
    Telegram.mainButtonLoading(false);
  }
}

// ── ORDER SUCCESS ─────────────────────────────────────────────────────────────

function renderOrderSuccess(order) {
  setHtml("view-order-success", `
    <div class="success-screen">
      <div class="success-screen__icon">✅</div>
      <h2>Заказ оформлен!</h2>
      <p class="success-screen__uid">#${order.order_uid}</p>
      <p>Менеджер свяжется с вами для подтверждения.</p>

      <div class="success-screen__details">
        <div class="meta-row">
          <span>💰 Сумма</span>
          <strong>${fmtPrice(order.total_price)}</strong>
        </div>
        <div class="meta-row">
          <span>📊 Статус</span>
          <strong>Новый</strong>
        </div>
      </div>

      <a class="btn btn--whatsapp" href="${order.whatsapp_link}" target="_blank">
        💬 Написать в WhatsApp
      </a>

      <button class="btn btn--outline" onclick="app.goTo('home')">
        🏠 На главную
      </button>
    </div>
  `);
  Telegram.hideMainButton();
}

// ── ORDERS HISTORY ────────────────────────────────────────────────────────────

async function loadOrders() {
  loader(true);
  try {
    state.orders = await API.getOrders();
    renderOrders();
  } catch (e) {
    toast("Ошибка загрузки заказов", "error");
  } finally {
    loader(false);
  }
}

function renderOrders() {
  if (!state.orders.length) {
    setHtml("view-orders", `
      <div class="view-header"><h2>📋 Мои заказы</h2></div>
      <div class="empty-state"><span>📋</span><p>У вас пока нет заказов</p></div>
    `);
    return;
  }

  const statusLabels = {
    new:         "🆕 Новый",
    confirmed:   "✅ Подтверждён",
    in_progress: "🔄 Готовится",
    done:        "✔️ Выполнен",
    cancelled:   "❌ Отменён",
  };

  const html = state.orders.map(o => {
    const date = new Date(o.event_date).toLocaleDateString("ru-RU", { day: "2-digit", month: "long", year: "numeric" });
    return `
      <div class="order-card">
        <div class="order-card__header">
          <span class="order-card__uid">#${o.order_uid}</span>
          <span class="order-card__status">${statusLabels[o.status] || o.status}</span>
        </div>
        <div class="order-card__meta">
          <span>📅 ${date}</span>
          <span>📍 ${o.location}</span>
        </div>
        <div class="order-card__footer">
          <strong>${fmtPrice(o.total_price)}</strong>
          <button class="btn btn--ghost btn--sm" onclick="app.repeatOrder(${o.id})">
            🔁 Повторить
          </button>
        </div>
      </div>
    `;
  }).join("");

  setHtml("view-orders", `
    <div class="view-header"><h2>📋 Мои заказы</h2></div>
    <div class="orders-list">${html}</div>
  `);
}

// ── PUBLIC API (called from HTML onclick) ─────────────────────────────────────

window.app = {
  goTo(view)        { navigate(view); },
  prevPage(catId)   { loadCatalog(catId, state.currentPage - 1); },
  nextPage(catId)   { loadCatalog(catId, state.currentPage + 1); },

  async repeatOrder(orderId) {
    try {
      const res = await API.repeatOrder(orderId);
      toast(res.message || "Добавлено в корзину");
      await refreshCart();
      Telegram.haptic.success();
    } catch (e) {
      toast(e.message || "Ошибка", "error");
    }
  },
};

// ── BOOTSTRAP ─────────────────────────────────────────────────────────────────

async function bootstrap() {
  Telegram.init();

  // Show loader
  loader(true);

  // Check Telegram availability
  if (!Telegram.isAvailable) {
    setHtml("loader", `
      <div style="text-align:center;padding:2rem;">
        <p>Откройте это приложение через Telegram</p>
      </div>
    `);
    return;
  }

  // Store user info
  state.user = Telegram.user;

  try {
    // Load user profile + cart + categories in parallel
    const [, cart, cats] = await Promise.all([
      API.getMe(),
      API.getCart(),
      API.getCategories(),
    ]);

    state.cart       = cart;
    state.categories = cats;

    renderHome();
    renderCategoryTabs();
    updateCartBadge();
  } catch (e) {
    console.error("Bootstrap error:", e);
  } finally {
    loader(false);
  }

  // Bind home nav buttons
  document.getElementById("nav-menu")?.addEventListener("click",  () => navigate("catalog"));
  document.getElementById("nav-cart")?.addEventListener("click",  () => navigate("cart"));
  document.getElementById("nav-orders")?.addEventListener("click",() => navigate("orders"));

  navigate("home");
}

// Start when DOM is ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bootstrap);
} else {
  bootstrap();
}
