/**
 * frontend/js/api.js
 * HTTP client for Qazaq Catering API.
 * Automatically attaches Telegram initData as auth header.
 */

import Telegram from "./telegram.js";

// Base URL of backend API — set to your domain in production
const BASE_URL = window.APP_CONFIG?.apiUrl || "https://yourdomain.com/api/v1";

/**
 * Core fetch wrapper.
 * Attaches X-Init-Data header on every request.
 * Throws on HTTP errors with parsed error message.
 */
async function request(method, path, body = null) {
  const headers = {
    "Content-Type": "application/json",
    "X-Init-Data":  Telegram.initData,
  };

  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);

  const res = await fetch(`${BASE_URL}${path}`, opts);

  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try {
      const err = await res.json();
      msg = err.detail || msg;
    } catch (_) {}
    throw new Error(msg);
  }

  return res.json();
}

const get  = (path)        => request("GET",    path);
const post = (path, body)  => request("POST",   path, body);
const del  = (path)        => request("DELETE", path);

// ── API methods ───────────────────────────────────────────────────────────────

export const API = {

  // User
  getMe: ()                          => get("/me"),

  // Catalog
  getCategories: ()                  => get("/categories"),
  getProducts:   (catId, page = 0)   => get(`/categories/${catId}/products?page=${page}`),
  getProduct:    (id)                => get(`/products/${id}`),

  // Cart
  getCart:       ()                  => get("/cart"),
  addToCart:     (body)              => post("/cart", body),
  removeFromCart:(productId)         => del(`/cart/${productId}`),
  clearCart:     ()                  => del("/cart"),

  // Orders
  checkout:      (body)              => post("/orders/checkout", body),
  getOrders:     ()                  => get("/orders"),
  repeatOrder:   (orderId)           => post(`/orders/${orderId}/repeat`),
};

export default API;
