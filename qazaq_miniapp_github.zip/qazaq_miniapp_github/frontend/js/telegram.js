/**
 * frontend/js/telegram.js
 * Wrapper around window.Telegram.WebApp API.
 * Provides a clean interface for all Telegram Mini App interactions.
 */

const TG = window.Telegram.WebApp;

const Telegram = {

  /** Initialize the Mini App — call once on page load */
  init() {
    TG.ready();                          // Signal Telegram the app is ready
    TG.expand();                         // Expand to full height
    TG.enableClosingConfirmation();      // Ask before closing if user has items in cart
    this._applyTheme();
  },

  /** Apply Telegram color theme to CSS variables */
  _applyTheme() {
    const c = TG.themeParams;
    const r = document.documentElement.style;
    if (c.bg_color)          r.setProperty("--tg-bg",       c.bg_color);
    if (c.text_color)        r.setProperty("--tg-text",     c.text_color);
    if (c.hint_color)        r.setProperty("--tg-hint",     c.hint_color);
    if (c.link_color)        r.setProperty("--tg-link",     c.link_color);
    if (c.button_color)      r.setProperty("--tg-btn",      c.button_color);
    if (c.button_text_color) r.setProperty("--tg-btn-text", c.button_text_color);
    if (c.secondary_bg_color)r.setProperty("--tg-sec-bg",   c.secondary_bg_color);
  },

  /** Returns the raw initData string (for API auth header) */
  get initData() {
    return TG.initData || "";
  },

  /** Returns parsed user object from Telegram */
  get user() {
    return TG.initDataUnsafe?.user || null;
  },

  /** Returns true if running inside Telegram */
  get isAvailable() {
    return Boolean(TG.initData);
  },

  /** Show Telegram native back button */
  showBack(callback) {
    TG.BackButton.show();
    TG.BackButton.onClick(callback);
  },

  /** Hide Telegram native back button */
  hideBack() {
    TG.BackButton.hide();
    TG.BackButton.offClick();
  },

  /** Show Telegram native main button (bottom) */
  showMainButton(text, callback) {
    TG.MainButton.setText(text);
    TG.MainButton.show();
    TG.MainButton.onClick(callback);
    TG.MainButton.enable();
  },

  /** Update main button text */
  setMainButtonText(text) {
    TG.MainButton.setText(text);
  },

  /** Show loading spinner on main button */
  mainButtonLoading(state) {
    if (state) TG.MainButton.showProgress(false);
    else        TG.MainButton.hideProgress();
  },

  /** Hide main button */
  hideMainButton() {
    TG.MainButton.hide();
    TG.MainButton.offClick();
  },

  /** Show native Telegram popup */
  alert(message) {
    return new Promise(resolve => TG.showAlert(message, resolve));
  },

  /** Show native Telegram confirm dialog */
  confirm(message) {
    return new Promise(resolve => TG.showConfirm(message, resolve));
  },

  /** Haptic feedback */
  haptic: {
    light()    { TG.HapticFeedback.impactOccurred("light");    },
    medium()   { TG.HapticFeedback.impactOccurred("medium");   },
    success()  { TG.HapticFeedback.notificationOccurred("success");  },
    error()    { TG.HapticFeedback.notificationOccurred("error");    },
    warning()  { TG.HapticFeedback.notificationOccurred("warning");  },
  },

  /** Close the Mini App */
  close() {
    TG.close();
  },

  /** Open external URL */
  openLink(url) {
    TG.openLink(url);
  },

  /** Send data back to the bot (triggers web_app_data message) */
  sendData(data) {
    TG.sendData(typeof data === "string" ? data : JSON.stringify(data));
  },

  /** Is dark theme active? */
  get isDark() {
    return TG.colorScheme === "dark";
  },
};

export default Telegram;
