# 🚀 Qazaq Catering Mini App — Deployment Guide

## Структура проекта

```
qazaq_miniapp/
├── backend/                   Python (FastAPI + aiogram)
│   ├── api/routes.py          18 REST endpoints
│   ├── bot/handlers/          aiogram handlers
│   ├── config/                settings, logging
│   ├── models/                SQLAlchemy ORM (7 tables)
│   ├── repositories/          data access layer
│   ├── services/              business logic
│   ├── utils/security.py      Telegram initData HMAC validation
│   ├── middlewares/           DB session, user registration, errors
│   ├── scheduler/             APScheduler (review requests)
│   ├── main.py                entry point (FastAPI + webhook)
│   └── requirements.txt
├── frontend/                  Vanilla JS Mini App
│   ├── index.html             Single page
│   ├── css/style.css          Full UI, Telegram theme-aware
│   └── js/
│       ├── telegram.js        Telegram WebApp API wrapper
│       ├── api.js             HTTP client (attaches X-Init-Data)
│       └── app.js             App controller (catalog, cart, checkout)
├── nginx/nginx.conf           SSL + reverse proxy
├── docker/
│   ├── Dockerfile             Multi-stage Python build
│   └── docker-compose.yml     backend + nginx
├── .env.example               Secrets template
└── DEPLOY.md                  This file
```

---

## Шаг 1 — Подготовка сервера

```bash
# Обновить систему
apt update && apt upgrade -y

# Установить Docker
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker

# Установить docker-compose v2
apt install -y docker-compose-plugin
docker compose version
```

---

## Шаг 2 — Настройка домена

1. Купи домен (namecheap, reg.ru, godaddy)
2. Создай A-запись: `yourdomain.com → IP твоего VPS`
3. Подожди 5-30 минут пока DNS распространится:
   ```bash
   nslookup yourdomain.com
   ```

---

## Шаг 3 — SSL сертификат (Let's Encrypt + Certbot)

```bash
# Установить certbot
apt install -y certbot

# Остановить nginx если запущен
systemctl stop nginx || true

# Получить сертификат (standalone — запускает свой HTTP сервер)
certbot certonly --standalone \
  -d yourdomain.com \
  --agree-tos \
  --no-eff-email \
  -m your@email.com

# Проверить что сертификат создан
ls /etc/letsencrypt/live/yourdomain.com/
# Должны быть: fullchain.pem, privkey.pem
```

**Автообновление сертификата:**
```bash
# Cron задача для автообновления
echo "0 12 * * * root certbot renew --quiet --pre-hook 'docker compose -f /root/qazaq_miniapp/docker/docker-compose.yml stop nginx' --post-hook 'docker compose -f /root/qazaq_miniapp/docker/docker-compose.yml start nginx'" >> /etc/crontab
```

---

## Шаг 4 — Настройка проекта

```bash
# Клонировать / загрузить проект
cd /root
unzip qazaq_miniapp.zip
cd qazaq_miniapp

# Создать .env из примера
cp .env.example .env
nano .env
```

Заполни `.env`:
```env
BOT_TOKEN=8773381320:xxxxxxxxxxxxxxxxxxxxxxxx
DATABASE_URL=postgresql+asyncpg://neondb_owner:xxxx@ep-xxx.neon.tech/neondb?ssl=require
GEMINI_KEY=AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxxx
ADMIN_ID=5720010749
ADMIN_PHONE=77001234567
ADMIN_WHATSAPP=77001234567
WEBHOOK_HOST=https://yourdomain.com
WEBAPP_URL=https://yourdomain.com
SECRET_KEY=your_random_32_char_secret_here
```

---

## Шаг 5 — Настройка nginx.conf и frontend

```bash
# Заменить yourdomain.com на твой домен
sed -i 's/yourdomain.com/ТВОЙ_ДОМЕН/g' nginx/nginx.conf

# То же в frontend/index.html
sed -i 's/yourdomain.com/ТВОЙ_ДОМЕН/g' frontend/index.html
```

---

## Шаг 6 — Запуск

```bash
cd /root/qazaq_miniapp

# Собрать и запустить
docker compose -f docker/docker-compose.yml up -d --build

# Проверить логи
docker compose -f docker/docker-compose.yml logs -f backend

# Проверить статус
docker compose -f docker/docker-compose.yml ps
```

Должно быть:
```
NAME              STATUS
qazaq_backend     Up (healthy)
qazaq_nginx       Up
```

---

## Шаг 7 — Зарегистрировать Mini App в BotFather

1. Открой @BotFather в Telegram
2. Выбери своего бота → **Bot Settings** → **Menu Button**
3. Введи URL: `https://yourdomain.com`
4. Введи название кнопки: `🛍 Открыть меню`

---

## Шаг 8 — Проверка

```bash
# API health check
curl https://yourdomain.com/health

# Категории (без авторизации)
curl https://yourdomain.com/api/v1/categories

# Webhook статус
curl https://api.telegram.org/botТВОЙ_ТОКЕН/getWebhookInfo
```

---

## Управление

```bash
# Перезапустить backend
docker compose -f docker/docker-compose.yml restart backend

# Обновить код (после изменений)
docker compose -f docker/docker-compose.yml up -d --build backend

# Остановить всё
docker compose -f docker/docker-compose.yml down

# Логи в реальном времени
docker compose -f docker/docker-compose.yml logs -f
```

---

## Как работает архитектура

```
Пользователь открывает Mini App в Telegram
         ↓
Telegram загружает https://yourdomain.com
         ↓
Nginx отдаёт frontend/index.html (статика)
         ↓
app.js инициализирует Telegram.WebApp
         ↓
Получает initData (подписано Telegram)
         ↓
API запросы → /api/v1/* с заголовком X-Init-Data
         ↓
Nginx проксирует на 127.0.0.1:8000
         ↓
FastAPI валидирует initData (HMAC-SHA256)
         ↓
Выполняет бизнес-логику → PostgreSQL
         ↓
Возвращает JSON → frontend рендерит UI

Параллельно:
Telegram → POST /webhook → aiogram → handlers
```

---

## Безопасность initData

Каждый API запрос валидируется через `utils/security.py`:

```python
# Алгоритм Telegram:
secret_key = HMAC-SHA256("WebAppData", bot_token)
expected    = HMAC-SHA256(secret_key, data_check_string)

# Если expected != received_hash → 401 Unauthorized
```

Это гарантирует что данные пришли именно от Telegram и не были подделаны.
