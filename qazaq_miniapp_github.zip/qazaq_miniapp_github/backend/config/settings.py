"""
backend/config/settings.py
Single source of truth for all configuration.
Loaded from .env via pydantic-settings.
"""

from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    # ── Telegram Bot ─────────────────────────────────────────
    bot_token: str        = Field("", env="BOT_TOKEN")
    admin_id: int         = Field(0,  env="ADMIN_ID")
    admin_phone: str      = Field("", env="ADMIN_PHONE")
    admin_whatsapp: str   = Field("", env="ADMIN_WHATSAPP")

    # ── Database ─────────────────────────────────────────────
    database_url: str     = Field("", env="DATABASE_URL")

    # ── AI ───────────────────────────────────────────────────
    gemini_key: str       = Field("", env="GEMINI_KEY")
    gemini_model: str     = "gemini-1.5-flash"

    # ── Server ───────────────────────────────────────────────
    app_host: str         = Field("0.0.0.0", env="APP_HOST")
    app_port: int         = Field(8000,      env="APP_PORT")
    webhook_host: str     = Field("",        env="WEBHOOK_HOST")
    webhook_path: str     = Field("/webhook",env="WEBHOOK_PATH")
    webapp_url: str       = Field("",        env="WEBAPP_URL")

    # ── Security ─────────────────────────────────────────────
    secret_key: str       = Field("", env="SECRET_KEY")

    # ── Business logic ────────────────────────────────────────
    min_lead_hours: int   = 24
    items_per_page: int   = 5

    @property
    def webhook_url(self) -> str:
        return f"{self.webhook_host}{self.webhook_path}"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"


settings = Settings()
