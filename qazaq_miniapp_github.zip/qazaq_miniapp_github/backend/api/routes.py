"""
backend/api/routes.py
FastAPI endpoints consumed by the Telegram Mini App frontend.
All protected endpoints require valid Telegram initData.
"""

import math
from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException, Header, status
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

from models.base import get_session
from models.models import User, OrderStatus
from repositories.user_repo import UserRepository
from repositories.product_repo import CategoryRepository, ProductRepository
from repositories.cart_repo import CartRepository
from repositories.order_repo import OrderRepository
from services.cart_service import CartService
from services.order_service import OrderService, OrderValidationError
from utils.security import validate_init_data, InitDataValidationError
from utils.date_parser import parse_date, parse_time, combine_datetime
from config import settings, get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/api/v1", tags=["Mini App API"])


# ── Dependency: validate initData and return user dict ───────────────────────

async def get_tg_user(
    x_init_data: Annotated[str, Header(alias="X-Init-Data")] = "",
) -> dict:
    """
    FastAPI dependency.
    Reads X-Init-Data header, validates it, returns parsed user dict.
    """
    if not x_init_data:
        raise HTTPException(status_code=401, detail="X-Init-Data header missing")
    try:
        data = validate_init_data(x_init_data)
        return data.get("user", {})
    except InitDataValidationError as e:
        raise HTTPException(status_code=401, detail=str(e))


async def get_or_create_user(
    tg_user: Annotated[dict, Depends(get_tg_user)],
    session: AsyncSession = Depends(get_session),
) -> User:
    """Auto-register user from initData on every API call."""
    repo = UserRepository(session)
    user, _ = await repo.get_or_create(
        user_id=int(tg_user["id"]),
        username=tg_user.get("username"),
        full_name=f"{tg_user.get('first_name', '')} {tg_user.get('last_name', '')}".strip(),
    )
    return user


# ════════════════════════════════════════════════════════════════
#  PUBLIC — no auth required
# ════════════════════════════════════════════════════════════════

@router.get("/health")
async def health_check():
    """Health check endpoint for docker/nginx."""
    return {"status": "ok", "service": "Qazaq Catering API"}


@router.get("/categories")
async def get_categories(session: AsyncSession = Depends(get_session)):
    """Return all active categories."""
    cats = await CategoryRepository(session).get_active()
    return [
        {"id": c.id, "name": c.name, "emoji": c.emoji, "description": c.description}
        for c in cats
    ]


@router.get("/categories/{cat_id}/products")
async def get_products(
    cat_id: int,
    page: int = 0,
    session: AsyncSession = Depends(get_session),
):
    """Paginated list of available products in a category."""
    per_page = settings.items_per_page
    repo     = ProductRepository(session)
    products = await repo.get_by_category(cat_id, available_only=True, offset=page * per_page, limit=per_page)
    total    = await repo.count_by_category(cat_id)

    return {
        "products": [
            {
                "id":             p.id,
                "name":           p.name,
                "description":    p.description,
                "price":          float(p.price),
                "photo_file_id":  p.photo_file_id,
                "serving_factor": p.serving_factor,
                "is_available":   p.is_available,
            }
            for p in products
        ],
        "total":    total,
        "page":     page,
        "pages":    math.ceil(total / per_page),
        "per_page": per_page,
    }


@router.get("/products/{product_id}")
async def get_product(product_id: int, session: AsyncSession = Depends(get_session)):
    """Single product detail."""
    product = await ProductRepository(session).get_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return {
        "id":             product.id,
        "name":           product.name,
        "description":    product.description,
        "price":          float(product.price),
        "photo_file_id":  product.photo_file_id,
        "serving_factor": product.serving_factor,
        "category_id":    product.category_id,
    }


# ════════════════════════════════════════════════════════════════
#  USER — requires valid initData
# ════════════════════════════════════════════════════════════════

@router.get("/me")
async def get_me(user: Annotated[User, Depends(get_or_create_user)]):
    """Return current user profile."""
    return {
        "id":         user.id,
        "username":   user.username,
        "full_name":  user.full_name,
        "is_active":  user.is_active,
        "created_at": user.created_at.isoformat(),
    }


# ── Cart ─────────────────────────────────────────────────────────────────────

@router.get("/cart")
async def get_cart(
    user: Annotated[User, Depends(get_or_create_user)],
    session: AsyncSession = Depends(get_session),
):
    """Return current user's cart with totals."""
    service = CartService(session)
    cart    = await service.get_cart_summary(user.id)
    return {
        "items": [
            {
                "product_id":   row["product"].id,
                "product_name": row["product"].name,
                "price":        float(row["product"].price),
                "quantity":     row["quantity"],
                "subtotal":     float(row["subtotal"]),
                "calc_mode":    row["calc_mode"],
                "guests_count": row["guests_count"],
            }
            for row in cart["items"]
        ],
        "total": float(cart["total"]),
        "count": cart["count"],
    }


class AddToCartRequest(BaseModel):
    product_id:   int
    quantity:     int | None = None    # For manual mode
    guests_count: int | None = None    # For per-person mode
    calc_mode:    str = "manual"       # "manual" | "per_person"


@router.post("/cart")
async def add_to_cart(
    body: AddToCartRequest,
    user: Annotated[User, Depends(get_or_create_user)],
    session: AsyncSession = Depends(get_session),
):
    """Add or update cart item. Supports manual and per-person modes."""
    service = CartService(session)

    if body.calc_mode == "per_person":
        if not body.guests_count or body.guests_count <= 0:
            raise HTTPException(status_code=400, detail="guests_count required for per_person mode")
        result = await service.add_per_person(user.id, body.product_id, body.guests_count)
    else:
        if not body.quantity or body.quantity <= 0:
            raise HTTPException(status_code=400, detail="quantity required for manual mode")
        result = await service.add_manual(user.id, body.product_id, body.quantity)

    return {"message": result}


@router.delete("/cart/{product_id}")
async def remove_from_cart(
    product_id: int,
    user: Annotated[User, Depends(get_or_create_user)],
    session: AsyncSession = Depends(get_session),
):
    """Remove a single product from cart."""
    await CartService(session).remove_item(user.id, product_id)
    return {"message": "Removed"}


@router.delete("/cart")
async def clear_cart(
    user: Annotated[User, Depends(get_or_create_user)],
    session: AsyncSession = Depends(get_session),
):
    """Clear entire cart."""
    await CartService(session).clear(user.id)
    return {"message": "Cart cleared"}


# ── Orders ────────────────────────────────────────────────────────────────────

class CheckoutRequest(BaseModel):
    client_name: str
    event_date:  str   # "DD.MM.YYYY"
    event_time:  str   # "HH:MM"
    location:    str


@router.post("/orders/checkout")
async def checkout(
    body: CheckoutRequest,
    user: Annotated[User, Depends(get_or_create_user)],
    session: AsyncSession = Depends(get_session),
):
    """
    Full checkout flow:
    1. Parse and validate date/time
    2. Validate 24h lead time
    3. Create order from cart
    4. Return order details + WhatsApp link
    """
    # Parse date
    date = parse_date(body.event_date)
    if not date:
        raise HTTPException(status_code=400, detail="Invalid date format. Use DD.MM.YYYY")

    # Parse time
    parsed_time = parse_time(body.event_time)
    if not parsed_time:
        raise HTTPException(status_code=400, detail="Invalid time format. Use HH:MM")

    event_dt = combine_datetime(date, *parsed_time)
    service  = OrderService(session)

    try:
        order = await service.checkout(
            user_id=user.id,
            client_name=body.client_name,
            event_date=event_dt,
            location=body.location,
        )
    except OrderValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

    whatsapp = await service.get_whatsapp_link(order)

    # Notify admin via bot
    try:
        from models.base import AsyncSessionLocal
        async with AsyncSessionLocal() as admin_session:
            full_order = await OrderRepository(admin_session).get_with_items(order.id)
            from utils.formatters import fmt_order_summary
            from aiogram import Bot
            bot = Bot(token=settings.bot_token)
            await bot.send_message(
                settings.admin_id,
                f"🔔 *НОВЫЙ ЗАКАЗ (Mini App) #{order.order_uid}*\n\n{fmt_order_summary(full_order)}",
                parse_mode="Markdown",
            )
            await bot.session.close()
    except Exception as e:
        logger.error(f"Admin notify failed: {e}")

    return {
        "order_uid":      order.order_uid,
        "total_price":    float(order.total_price),
        "status":         order.status,
        "whatsapp_link":  whatsapp,
        "event_date":     order.event_date.isoformat(),
    }


@router.get("/orders")
async def get_my_orders(
    user: Annotated[User, Depends(get_or_create_user)],
    session: AsyncSession = Depends(get_session),
):
    """Return user's order history."""
    orders = await OrderRepository(session).get_user_orders(user.id)
    return [
        {
            "id":          o.id,
            "order_uid":   o.order_uid,
            "event_date":  o.event_date.isoformat(),
            "location":    o.location,
            "total_price": float(o.total_price),
            "status":      o.status,
            "items_count": len(o.items) if o.items else 0,
        }
        for o in orders
    ]


@router.post("/orders/{order_id}/repeat")
async def repeat_order(
    order_id: int,
    user: Annotated[User, Depends(get_or_create_user)],
    session: AsyncSession = Depends(get_session),
):
    """Copy items from a past order into current cart."""
    service = OrderService(session)
    result  = await service.repeat_order(user.id, order_id)
    return {"message": result}
