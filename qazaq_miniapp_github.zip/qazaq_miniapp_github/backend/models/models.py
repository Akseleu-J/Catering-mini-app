"""backend/models/models.py — Full ORM schema (unchanged from qazaq_pro)."""

from __future__ import annotations
import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    BigInteger, Boolean, DateTime, ForeignKey,
    Integer, Numeric, String, Text, func,
    UniqueConstraint, Index, CheckConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import Base


# ── Users ────────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"
    id: Mapped[int]          = mapped_column(BigInteger, primary_key=True)
    username: Mapped[str | None]  = mapped_column(String(64), nullable=True)
    full_name: Mapped[str]   = mapped_column(String(256), nullable=False)
    phone: Mapped[str | None]= mapped_column(String(20), nullable=True)
    is_active: Mapped[bool]  = mapped_column(Boolean, default=True)
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    cart_items: Mapped[list[CartItem]] = relationship(back_populates="user", cascade="all, delete-orphan")
    orders: Mapped[list[Order]]        = relationship(back_populates="user")
    reviews: Mapped[list[Review]]      = relationship(back_populates="user")


# ── Categories ───────────────────────────────────────────────────────────────

class Category(Base):
    __tablename__ = "categories"
    id: Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str]         = mapped_column(String(100), nullable=False, unique=True)
    emoji: Mapped[str]        = mapped_column(String(10), default="🍽")
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    sort_order: Mapped[int]   = mapped_column(Integer, default=0)
    is_active: Mapped[bool]   = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    products: Mapped[list[Product]] = relationship(back_populates="category")


# ── Products ─────────────────────────────────────────────────────────────────

class Product(Base):
    __tablename__ = "products"
    id: Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    category_id: Mapped[int]  = mapped_column(Integer, ForeignKey("categories.id", ondelete="CASCADE"))
    name: Mapped[str]         = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    price: Mapped[Decimal]    = mapped_column(Numeric(12, 2), nullable=False)
    photo_file_id: Mapped[str | None] = mapped_column(Text, nullable=True)
    serving_factor: Mapped[int] = mapped_column(Integer, default=1)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    category: Mapped[Category]      = relationship(back_populates="products")
    cart_items: Mapped[list[CartItem]] = relationship(back_populates="product")
    order_items: Mapped[list[OrderItem]] = relationship(back_populates="product")

    __table_args__ = (
        CheckConstraint("price > 0"),
        CheckConstraint("serving_factor > 0"),
        Index("ix_products_category", "category_id"),
        Index("ix_products_available", "is_available"),
    )


# ── Cart Items ────────────────────────────────────────────────────────────────

class CartItem(Base):
    __tablename__ = "cart_items"
    id: Mapped[int]         = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int]    = mapped_column(BigInteger, ForeignKey("users.id", ondelete="CASCADE"))
    product_id: Mapped[int] = mapped_column(Integer, ForeignKey("products.id", ondelete="CASCADE"))
    quantity: Mapped[int]   = mapped_column(Integer, default=1)
    calc_mode: Mapped[str]  = mapped_column(String(20), default="manual")
    guests_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    user: Mapped[User]       = relationship(back_populates="cart_items")
    product: Mapped[Product] = relationship(back_populates="cart_items")

    __table_args__ = (
        UniqueConstraint("user_id", "product_id"),
        CheckConstraint("quantity > 0"),
        Index("ix_cart_user", "user_id"),
    )


# ── Orders ────────────────────────────────────────────────────────────────────

class OrderStatus:
    NEW        = "new"
    CONFIRMED  = "confirmed"
    IN_PROGRESS= "in_progress"
    DONE       = "done"
    CANCELLED  = "cancelled"


class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    order_uid: Mapped[str]    = mapped_column(String(12), unique=True, nullable=False, default=lambda: uuid.uuid4().hex[:8].upper())
    user_id: Mapped[int | None] = mapped_column(BigInteger, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    client_name: Mapped[str]  = mapped_column(String(200), nullable=False)
    event_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    location: Mapped[str]     = mapped_column(Text, nullable=False)
    total_price: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=0)
    status: Mapped[str]       = mapped_column(String(30), default=OrderStatus.NEW)
    whatsapp_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    user: Mapped[User | None]      = relationship(back_populates="orders")
    items: Mapped[list[OrderItem]] = relationship(back_populates="order", cascade="all, delete-orphan")
    review: Mapped[Review | None]  = relationship(back_populates="order", uselist=False)

    __table_args__ = (
        Index("ix_orders_user", "user_id"),
        Index("ix_orders_status", "status"),
        Index("ix_orders_event_date", "event_date"),
    )


# ── Order Items ───────────────────────────────────────────────────────────────

class OrderItem(Base):
    __tablename__ = "order_items"
    id: Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    order_id: Mapped[int]     = mapped_column(Integer, ForeignKey("orders.id", ondelete="CASCADE"))
    product_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    product_name: Mapped[str] = mapped_column(String(200), nullable=False)
    unit_price: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    quantity: Mapped[int]     = mapped_column(Integer, nullable=False)

    order: Mapped[Order]           = relationship(back_populates="items")
    product: Mapped[Product | None]= relationship(back_populates="order_items")


# ── Reviews ───────────────────────────────────────────────────────────────────

class Review(Base):
    __tablename__ = "reviews"
    id: Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    order_id: Mapped[int]     = mapped_column(Integer, ForeignKey("orders.id", ondelete="CASCADE"), unique=True)
    user_id: Mapped[int]      = mapped_column(BigInteger, ForeignKey("users.id", ondelete="CASCADE"))
    rating: Mapped[int | None]= mapped_column(Integer, nullable=True)
    text: Mapped[str | None]  = mapped_column(Text, nullable=True)
    review_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    review_created_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    order: Mapped[Order] = relationship(back_populates="review")
    user: Mapped[User]   = relationship(back_populates="reviews")

    __table_args__ = (
        CheckConstraint("rating BETWEEN 1 AND 5"),
        Index("ix_reviews_sent", "review_sent"),
    )
