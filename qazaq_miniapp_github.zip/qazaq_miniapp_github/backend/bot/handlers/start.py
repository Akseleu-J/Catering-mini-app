"""
backend/bot/handlers/start.py
/start command — now includes WebApp button to open Mini App.
"""

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext

from config import settings

router = Router()

WELCOME = (
    "🌟 *Добро пожаловать в Qazaq Catering!*\n\n"
    "Мы создаём незабываемые праздники в Шымкенте.\n\n"
    "🍽 Казахская и европейская кухня\n"
    "🎉 Тои, свадьбы, корпоративы\n"
    "🚚 Выездной сервис по городу\n\n"
    "👇 Откройте наше меню прямо в Telegram:"
)


def start_kb() -> InlineKeyboardMarkup:
    """
    Main keyboard with WebApp button.
    WebAppInfo tells Telegram to open the URL as a Mini App (bottom sheet).
    """
    buttons = []

    # WebApp button — opens Mini App as Telegram bottom sheet
    if settings.webapp_url:
        buttons.append([
            InlineKeyboardButton(
                text="🛍 Открыть меню (Mini App)",
                web_app=WebAppInfo(url=settings.webapp_url),
            )
        ])

    # Regular bot fallback buttons
    buttons += [
        [
            InlineKeyboardButton(text="🍽 Меню",       callback_data="menu"),
            InlineKeyboardButton(text="🛒 Корзина",    callback_data="cart"),
        ],
        [
            InlineKeyboardButton(text="📋 Мои заказы", callback_data="my_orders"),
            InlineKeyboardButton(text="🤖 AI Помощник",callback_data="ai_chat"),
        ],
        [InlineKeyboardButton(text="📞 Связаться",     callback_data="contact")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(WELCOME, parse_mode="Markdown", reply_markup=start_kb())


@router.callback_query(F.data == "main")
async def cb_main(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    try:
        await callback.message.edit_text(WELCOME, parse_mode="Markdown", reply_markup=start_kb())
    except Exception:
        await callback.message.answer(WELCOME, parse_mode="Markdown", reply_markup=start_kb())
    await callback.answer()


@router.callback_query(F.data == "contact")
async def cb_contact(callback: CallbackQuery):
    try:
        await callback.message.edit_text(
            f"📞 *Свяжитесь с нами:*\n\nWhatsApp: +{settings.admin_whatsapp}",
            parse_mode="Markdown",
            reply_markup=start_kb(),
        )
    except Exception:
        await callback.message.answer(
            f"📞 WhatsApp: +{settings.admin_whatsapp}",
            reply_markup=start_kb(),
        )
    await callback.answer()
