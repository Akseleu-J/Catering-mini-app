"""
backend/utils/security.py
Telegram Mini App initData validation.
Implements the HMAC-SHA256 verification algorithm
as described in Telegram docs:
https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
"""

import hashlib
import hmac
import json
import time
from urllib.parse import unquote, parse_qsl
from typing import Optional

from config import settings


class InitDataValidationError(Exception):
    """Raised when Telegram initData fails validation."""
    pass


def validate_init_data(init_data: str, max_age_seconds: int = 86400) -> dict:
    """
    Validate Telegram WebApp initData string.

    Args:
        init_data: Raw initData string from window.Telegram.WebApp.initData
        max_age_seconds: Max allowed age of data (default 24h)

    Returns:
        dict with parsed user data and other fields

    Raises:
        InitDataValidationError if validation fails
    """
    if not init_data:
        raise InitDataValidationError("initData is empty")

    # Parse the query string into key-value pairs
    params = dict(parse_qsl(init_data, keep_blank_values=True))

    # Extract and remove hash from params (we'll verify it)
    received_hash = params.pop("hash", None)
    if not received_hash:
        raise InitDataValidationError("hash not found in initData")

    # Build data_check_string: sorted key=value pairs joined by \n
    data_check_string = "\n".join(
        f"{k}={v}" for k, v in sorted(params.items())
    )

    # Secret key = HMAC-SHA256("WebAppData", bot_token)
    secret_key = hmac.new(
        key=b"WebAppData",
        msg=settings.bot_token.encode(),
        digestmod=hashlib.sha256,
    ).digest()

    # Compute expected hash
    expected_hash = hmac.new(
        key=secret_key,
        msg=data_check_string.encode(),
        digestmod=hashlib.sha256,
    ).hexdigest()

    # Constant-time comparison to prevent timing attacks
    if not hmac.compare_digest(expected_hash, received_hash):
        raise InitDataValidationError("Hash mismatch — data may be forged")

    # Check data freshness
    auth_date = int(params.get("auth_date", 0))
    if time.time() - auth_date > max_age_seconds:
        raise InitDataValidationError("initData is too old")

    # Parse user JSON if present
    result = dict(params)
    if "user" in result:
        try:
            result["user"] = json.loads(unquote(result["user"]))
        except (json.JSONDecodeError, ValueError):
            raise InitDataValidationError("Failed to parse user JSON")

    return result


def extract_user_id(init_data: str) -> Optional[int]:
    """
    Quick extract of user_id from initData without full validation.
    Use only for non-sensitive operations.
    """
    try:
        validated = validate_init_data(init_data)
        user = validated.get("user", {})
        return int(user.get("id", 0)) or None
    except Exception:
        return None
