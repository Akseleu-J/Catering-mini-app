"""backend/utils/whatsapp.py"""
from urllib.parse import quote
from models.models import Order


def build_whatsapp_link(order: Order, phone: str) -> str:
    lines = [
        f"🎉 *Новый заказ #{order.order_uid}*",
        f"👤 Клиент: {order.client_name}",
        f"📅 Дата: {order.event_date.strftime('%d.%m.%Y %H:%M')}",
        f"📍 Адрес: {order.location}", "",
        "🍽 *Состав:*",
    ]
    for item in order.items:
        lines.append(f"  • {item.product_name} × {item.quantity} = {int(item.quantity * item.unit_price):,} ₸")
    lines += ["", f"💰 *Итого: {int(order.total_price):,} ₸*"]
    return f"https://wa.me/{phone}?text={quote(chr(10).join(lines))}"
