"""
backend/main.py
Unified entry point:
  - FastAPI serves the REST API for Mini App
  - aiogram runs via webhook (same process, same port)
  - Both share the same database pool

Architecture:
  Nginx → :8000 (uvicorn)
            ├── /webhook  → aiogram Update handler
            ├── /api/v1/* → FastAPI routes (Mini App)
            └── /         → Static frontend (optional)
"""

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Update

from config import settings, setup_logging, get_logger
from models import create_all_tables
from api import router as api_router
from scheduler import create_scheduler

# Import all bot handlers (reused from qazaq_pro)
from bot.handlers import start, menu, cart, checkout, orders, ai_handler, review, admin, broadcast
from middlewares.db_middleware import DbSessionMiddleware
from middlewares.user_middleware import UserMiddleware
from middlewares.error_middleware import ErrorMiddleware

setup_logging()
logger = get_logger(__name__)


# ── Bot + Dispatcher setup ────────────────────────────────────────────────────

bot = Bot(token=settings.bot_token)
dp  = Dispatcher(storage=MemoryStorage())

# Middlewares
dp.update.outer_middleware(ErrorMiddleware())
dp.update.outer_middleware(DbSessionMiddleware())
dp.update.outer_middleware(UserMiddleware())

# Routers (admin first)
dp.include_router(admin.router)
dp.include_router(broadcast.router)
dp.include_router(start.router)       # Replaces common.py — has WebApp button
dp.include_router(menu.router)
dp.include_router(cart.router)
dp.include_router(checkout.router)
dp.include_router(orders.router)
dp.include_router(review.router)
dp.include_router(ai_handler.router)  # Must be last (catches all text)


# ── App lifecycle ─────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Run on startup and shutdown."""
    # Startup
    logger.info("Starting up...")
    await create_all_tables()
    logger.info("DB tables verified ✅")

    # Set webhook
    await bot.set_webhook(
        url=settings.webhook_url,
        allowed_updates=dp.resolve_used_update_types(),
        drop_pending_updates=True,
    )
    logger.info(f"Webhook set to {settings.webhook_url} ✅")

    # Start scheduler
    scheduler = create_scheduler(bot)
    scheduler.start()
    logger.info("Scheduler started ✅")

    # Notify admin
    try:
        await bot.send_message(settings.admin_id, "🟢 *Бот + Mini App запущены!*", parse_mode="Markdown")
    except Exception:
        pass

    yield  # App is running

    # Shutdown
    scheduler.shutdown()
    await bot.delete_webhook()
    await bot.session.close()
    logger.info("Bot shut down cleanly ✅")


# ── FastAPI app ───────────────────────────────────────────────────────────────

app = FastAPI(
    title="Qazaq Catering API",
    description="REST API for Telegram Mini App + Bot webhook",
    version="2.0.0",
    lifespan=lifespan,
    docs_url="/docs",   # Disable in production: docs_url=None
    redoc_url=None,
)

# CORS — allow Telegram's webview to call our API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # Tighten in production to your domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API routes
app.include_router(api_router)

# Serve frontend static files (optional — nginx can do this instead)
# app.mount("/", StaticFiles(directory="../frontend", html=True), name="frontend")


# ── Webhook endpoint ──────────────────────────────────────────────────────────

@app.post(settings.webhook_path)
async def telegram_webhook(request: Request) -> JSONResponse:
    """
    Receives Telegram updates via webhook.
    Parses JSON body and feeds it to aiogram dispatcher.
    """
    body = await request.json()
    update = Update.model_validate(body, context={"bot": bot})
    await dp.feed_update(bot, update)
    return JSONResponse({"ok": True})


# ── Root health check ─────────────────────────────────────────────────────────

@app.get("/")
async def root():
    return {"service": "Qazaq Catering", "status": "running"}


# ── Dev runner ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=False,
        log_level="info",
    )
